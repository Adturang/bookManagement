package com.books.service;

import com.books.entity.User;

public interface UserService  {

	public User registerUser(User user);

	User login(String username,String password);
	
}
