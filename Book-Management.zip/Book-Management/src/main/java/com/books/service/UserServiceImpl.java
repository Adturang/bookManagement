package com.books.service;

import java.util.ArrayList;
import java.util.Collection;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.books.entity.Role;
import com.books.entity.User;
import com.books.repos.UserRepository;

@Service
public class UserServiceImpl implements UserService {

	@Autowired
	private UserRepository userRepository;
	

	@Override
	public User registerUser(User user) {
		Collection<Role> roles = new ArrayList<>();
		roles.add(new Role("ROLE_USER"));
		user.setRoles(roles);
		System.out.println("USER: "+user);
		return userRepository.save(user);
	}


	@Override
	public User login(String username, String password) {
		User user=userRepository.findByUsernameAndPassword(username, password);
		return user;
	}



	

}
