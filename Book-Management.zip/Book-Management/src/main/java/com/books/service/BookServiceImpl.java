package com.books.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.books.entity.Book;
import com.books.repos.BookRepository;

@Service
public class BookServiceImpl implements BookService {

	@Autowired
	private BookRepository bookRepository;
	
	@Override
	public Book getBook(Long id) {
		return bookRepository.findById(id).get();
	}

	@Override
	public List<Book> getAllBooks() {
		return bookRepository.findAll();
	}

	@Override
	public Book addBook(Book book) {
		return bookRepository.save(book);
	}

	@Override
	public Book upadteBook(Book book) {
		Book exstingBook = bookRepository.getOne(book.getId());
		exstingBook.setName(book.getName());
		exstingBook.setPrice(book.getPrice());
		exstingBook.setStockLeft(book.getStockLeft());
		exstingBook.setAuthor(book.getAuthor());
		return bookRepository.save(exstingBook);
	}

	@Override
	public void removeBook(Long id) {
		bookRepository.deleteById(id);
	}

}
