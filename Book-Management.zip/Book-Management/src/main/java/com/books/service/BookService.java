package com.books.service;

import java.util.List;

import com.books.entity.Book;

public interface BookService {

	public Book getBook(Long id);
	public List<Book> getAllBooks();
	public Book addBook(Book book);
	public Book upadteBook(Book book);
	public void removeBook(Long id);
	
}
