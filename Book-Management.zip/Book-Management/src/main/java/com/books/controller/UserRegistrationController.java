package com.books.controller;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.books.entity.User;
import com.books.repos.UserRepository;
import com.books.service.UserService;

@Controller
public class UserRegistrationController {

	@Autowired
	private UserService userService;
	@Autowired
	private UserRepository userRepository;
	
	@GetMapping("/registration")
	public String regi() {
		return "registration";
	}

	@PostMapping("/register")
	public String registerUserAccount(User user,Model model) {
		System.err.println(user);
		User existing = userRepository.findByUsername(user.getUsername());
		if (existing != null) {
			model.addAttribute("rmsg","There is already an account registered with that username");
			return "registration";
		}

		userService.registerUser(user);
		System.err.println("saved");
		model.addAttribute("rmsg","User Successfully Registerd");
		return "registration";
	}
	
	 @GetMapping("/")
	    public String showlogin() {
	        return "login";
	    }
	
	 @PostMapping("/login")
	    public String login(Model model,HttpSession session,@RequestParam("username") String username,@RequestParam("password") String password) {
		 	
		 	if (userService.login(username, password)!=null) {
				session.setAttribute("user", username);
			}else {
				model.addAttribute("errmsg","Invalid Credential");
				return  "login";
			}
	        return "redirect:/index";
	    }
	 @GetMapping("/logout")
	    public String logout(HttpSession session,Model model) {	
		 	if (session.getAttribute("user")!=null) {
				session.invalidate();
			}
		 	model.addAttribute("errmsg","Logged-Out Sussessfully");
			return  "login";
	    }
}
