package com.books.controller;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.books.entity.Book;
import com.books.service.BookService;

@Controller
public class BookController {

	@Autowired
	private BookService bookService;
	
	@RequestMapping("/index")
	public String showHome(HttpSession session, Model model) {
		model.addAttribute("BOOKS", bookService.getAllBooks());
		if(session.getAttribute("msg")!=null) {
			model.addAttribute("MSG", session.getAttribute("msg"));
			session.removeAttribute("msg");
		}
		return "index";
	}
	
	
	@RequestMapping("/show-add")
	public String showAddBook(HttpSession session,Model model) {
		if(session.getAttribute("user")==null) {
			model.addAttribute("errmsg","Your Session Expired Please Login");
			return "login";
		}
		return "addBook";
	}
	
	@PostMapping("/add")
	public String addBook(@ModelAttribute("Book") Book book, HttpSession session) {
		if(bookService.addBook(book)!=null){
			session.setAttribute("msg", "Book Successfully Added.");
		}
		else {
			session.setAttribute("msg", "Somethong Went wrong.!!!");
		}
		return "redirect:/index";
	}
	
	@GetMapping("/rm-b")
	public String removeBook(@RequestParam("id") Long id, HttpSession session,Model model) {
		if(session.getAttribute("user")==null) {
			model.addAttribute("errmsg","Your Session Expired Please Login");
			return "login";
		}
		bookService.removeBook(id);
		session.setAttribute("msg", "Book Removed Successfully.");
		return "redirect:/";
	}
	
	
	@RequestMapping("/show-update")
	public String showUpdateBook(@RequestParam("id") Long id, Model model,HttpSession session) {
		if(session.getAttribute("user")==null) {
			model.addAttribute("errmsg","Your Session Expired Please Login");
			return "login";
		}
		Book book = bookService.getBook(id);
		model.addAttribute("book", book);
		return "addUpdate";
	}
	
	
	@PostMapping("/update")
	public String updateBook(@ModelAttribute("Book") Book book, HttpSession session) {
		if(bookService.upadteBook(book)!=null){
			session.setAttribute("msg", "Book Successfully Updated.");
		}
		else {
			session.setAttribute("msg", "Somethong Went wrong.!!!");
		}
		return "redirect:/index";
	}
	
}
